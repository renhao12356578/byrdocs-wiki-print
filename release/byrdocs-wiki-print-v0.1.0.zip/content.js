"use strict";
(() => {
  // src/print-button.ts
  var STORAGE_KEY = "bdwp-print-button-position";
  var DRAG_THRESHOLD_PX = 5;
  var TOOLBAR_SNAP_PADDING_PX = 48;
  var PRINT_ICON = `
  <svg aria-hidden="true" class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8">
    <polyline points="6 9 6 2 18 2 18 9"></polyline>
    <path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path>
    <rect x="6" y="14" width="12" height="8"></rect>
  </svg>
`;
  function readPosition() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return { mode: "docked" };
      const parsed = JSON.parse(raw);
      if (parsed.mode === "free" && typeof parsed.x === "number" && typeof parsed.y === "number") {
        return parsed;
      }
      return { mode: "docked" };
    } catch {
      return { mode: "docked" };
    }
  }
  function savePosition(position) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(position));
    } catch {
    }
  }
  function clamp(value, min, max) {
    return Math.min(Math.max(value, min), max);
  }
  function getToolbarActions() {
    return document.getElementById("examToolbarActions");
  }
  function getToolbar() {
    return document.getElementById("examToolbar");
  }
  function clampFreePosition(x, y, button) {
    const maxX = Math.max(0, window.innerWidth - button.offsetWidth);
    const maxY = Math.max(0, window.innerHeight - button.offsetHeight);
    return {
      mode: "free",
      x: clamp(x, 0, maxX),
      y: clamp(y, 0, maxY)
    };
  }
  function applyFreePosition(button, x, y) {
    const clamped = clampFreePosition(x, y, button);
    button.classList.add("is-free");
    button.style.left = `${clamped.x}px`;
    button.style.top = `${clamped.y}px`;
    button.style.right = "auto";
    button.style.bottom = "auto";
  }
  function isButtonDocked(button) {
    const actions = getToolbarActions();
    return actions !== null && button.parentElement === actions && actions.firstElementChild === button && !button.classList.contains("is-free");
  }
  function dockButton(button) {
    const actions = getToolbarActions();
    if (!actions) return false;
    button.hidden = false;
    if (isButtonDocked(button)) {
      return true;
    }
    button.classList.remove("is-free", "is-dragging");
    button.style.left = "";
    button.style.top = "";
    button.style.right = "";
    button.style.bottom = "";
    actions.insertBefore(button, actions.firstChild);
    return true;
  }
  function isNearToolbar(button) {
    const toolbar = getToolbar();
    if (!toolbar) return false;
    const toolbarRect = toolbar.getBoundingClientRect();
    const buttonRect = button.getBoundingClientRect();
    const centerX = buttonRect.left + buttonRect.width / 2;
    const centerY = buttonRect.top + buttonRect.height / 2;
    return centerX >= toolbarRect.left - TOOLBAR_SNAP_PADDING_PX && centerX <= toolbarRect.right + TOOLBAR_SNAP_PADDING_PX && centerY >= toolbarRect.top - TOOLBAR_SNAP_PADDING_PX && centerY <= toolbarRect.bottom + TOOLBAR_SNAP_PADDING_PX;
  }
  function createPrintButton() {
    const button = document.createElement("button");
    button.id = "bdwpPrintControl";
    button.type = "button";
    button.className = "floating-toolbar-control cursor-pointer active:scale-95 bdwp-print-control";
    button.setAttribute("aria-label", "\u6253\u5370\u8BD5\u5377");
    button.setAttribute("data-tooltip", "\u6253\u5370\u8BD5\u5377\uFF08\u6269\u5C55\uFF0C\u53EF\u62D6\u62FD\uFF09");
    button.title = "\u6253\u5370\u8BD5\u5377\uFF08\u6269\u5C55\uFF0C\u53EF\u62D6\u62FD\uFF09";
    button.innerHTML = PRINT_ICON;
    return button;
  }
  function setupDraggable(button, onClick) {
    let pointerId = null;
    let startX = 0;
    let startY = 0;
    let offsetX = 0;
    let offsetY = 0;
    let moved = false;
    let dragging = false;
    const finishDrag = (event) => {
      if (pointerId !== event.pointerId) return;
      button.releasePointerCapture(event.pointerId);
      pointerId = null;
      button.classList.remove("is-dragging");
      if (dragging) {
        if (isNearToolbar(button)) {
          savePosition({ mode: "docked" });
          dockButton(button);
        } else {
          const rect = button.getBoundingClientRect();
          const position = clampFreePosition(rect.left, rect.top, button);
          savePosition(position);
          applyFreePosition(button, position.x, position.y);
        }
      } else {
        onClick();
      }
      dragging = false;
      moved = false;
    };
    button.addEventListener("pointerdown", (event) => {
      if (event.button !== 0) return;
      pointerId = event.pointerId;
      startX = event.clientX;
      startY = event.clientY;
      moved = false;
      dragging = false;
      const rect = button.getBoundingClientRect();
      offsetX = event.clientX - rect.left;
      offsetY = event.clientY - rect.top;
      button.setPointerCapture(event.pointerId);
    });
    button.addEventListener("pointermove", (event) => {
      if (pointerId !== event.pointerId) return;
      const deltaX = event.clientX - startX;
      const deltaY = event.clientY - startY;
      if (!moved && Math.hypot(deltaX, deltaY) < DRAG_THRESHOLD_PX) return;
      if (!moved) {
        moved = true;
        dragging = true;
        button.classList.add("is-dragging");
        if (!button.classList.contains("is-free")) {
          document.body.appendChild(button);
          applyFreePosition(
            button,
            event.clientX - offsetX,
            event.clientY - offsetY
          );
        }
      }
      applyFreePosition(
        button,
        event.clientX - offsetX,
        event.clientY - offsetY
      );
    });
    button.addEventListener("pointerup", finishDrag);
    button.addEventListener("pointercancel", finishDrag);
  }
  function mountPrintButton(onClick) {
    const existing = document.getElementById("bdwpPrintControl");
    if (existing instanceof HTMLButtonElement) {
      return existing;
    }
    const button = createPrintButton();
    setupDraggable(button, onClick);
    const position = readPosition();
    if (position.mode === "docked") {
      if (dockButton(button)) {
        return button;
      }
      button.hidden = true;
      document.body.appendChild(button);
      return button;
    }
    document.body.appendChild(button);
    applyFreePosition(button, position.x ?? 16, position.y ?? 16);
    return button;
  }
  function needsPlacementSync() {
    if (readPosition().mode !== "docked") return false;
    const button = document.getElementById("bdwpPrintControl");
    if (!(button instanceof HTMLButtonElement)) return false;
    if (!getToolbarActions()) return false;
    return !isButtonDocked(button);
  }
  function isPrintUiReady() {
    if (!document.getElementById("bdwpPrintDialog")) return false;
    const button = document.getElementById("bdwpPrintControl");
    if (!(button instanceof HTMLButtonElement)) return false;
    if (readPosition().mode === "free") return true;
    if (!getToolbarActions()) return false;
    return isButtonDocked(button);
  }
  function ensurePrintButtonPlacement() {
    const button = document.getElementById("bdwpPrintControl");
    if (!(button instanceof HTMLButtonElement)) return;
    const position = readPosition();
    if (position.mode !== "docked") return;
    if (!getToolbarActions()) return;
    if (isButtonDocked(button)) return;
    dockButton(button);
  }

  // src/print-appendix.ts
  function findPrecedingHeadings(el) {
    const root = el.closest(".exam-page-main") || el.closest(".wiki-content") || document.body;
    const headings = root.querySelectorAll("h1, h2, h3, h4, h5, h6");
    let section = "";
    let subsection = "";
    for (let i = headings.length - 1; i >= 0; i -= 1) {
      const heading = headings[i];
      if (!(heading.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_FOLLOWING)) {
        continue;
      }
      const level = Number(heading.tagName.slice(1));
      const text = (heading.textContent || "").trim();
      if (!text) continue;
      if (level >= 3) {
        if (!subsection) subsection = text;
        continue;
      }
      section = text;
      break;
    }
    return { section, subsection };
  }
  function findListIndexLabel(el) {
    const li = el.closest("li");
    if (li?.parentElement) {
      const listParent = li.parentElement;
      let start = Number.parseInt(listParent.getAttribute("start") || "1", 10);
      if (!Number.isFinite(start)) start = 1;
      const items = Array.from(listParent.children).filter(
        (child) => child.tagName === "LI"
      );
      const index = items.indexOf(li);
      if (index >= 0) return String(start + index);
    }
    let prev = el.previousElementSibling;
    while (prev) {
      if (prev.classList.contains("exam-blank") || prev.classList.contains("exam-choices") || prev.classList.contains("exam-solution") || /^H[1-6]$/.test(prev.tagName)) {
        break;
      }
      if (prev.tagName === "OL" || prev.tagName === "UL") {
        let listStart = Number.parseInt(prev.getAttribute("start") || "1", 10);
        if (!Number.isFinite(listStart)) listStart = 1;
        const listItems = Array.from(prev.children).filter(
          (child) => child.tagName === "LI"
        );
        if (listItems.length) return String(listStart + listItems.length - 1);
      }
      const prevText = (prev.textContent || "").trim();
      const numbered = prevText.match(/^(\d+)\s*[.、]/);
      if (numbered) return numbered[1];
      prev = prev.previousElementSibling;
    }
    return "";
  }
  function buildLocalAnswerLabel(el, fallbackIndex) {
    if (el.classList.contains("exam-choices")) {
      const choiceText = (el.querySelector(".exam-choices-item")?.textContent || "").trim();
      if (choiceText) return { label: choiceText, sort: null };
    }
    const headings = findPrecedingHeadings(el);
    if (headings.subsection) {
      return { label: headings.subsection, sort: null };
    }
    const listIndex = findListIndexLabel(el);
    if (listIndex) {
      return { label: `${listIndex}.`, sort: Number(listIndex) };
    }
    return { label: `${fallbackIndex}.`, sort: fallbackIndex };
  }
  function buildPrintAnswerLabel(el, fallbackIndex) {
    const local = buildLocalAnswerLabel(el, fallbackIndex);
    const headings = findPrecedingHeadings(el);
    if (el.classList.contains("exam-choices")) {
      const choiceText = (el.querySelector(".exam-choices-item")?.textContent || "").trim();
      if (choiceText) return choiceText;
    }
    const parts = [];
    if (headings.section) parts.push(headings.section);
    if (local.label) parts.push(local.label);
    if (parts.length) return parts.join(" \xB7 ");
    return String(fallbackIndex);
  }
  function appendClonedChildren(target, source) {
    source.childNodes.forEach((node) => {
      target.appendChild(node.cloneNode(true));
    });
  }
  function isElementAfter(el, marker) {
    return !!(marker.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_FOLLOWING);
  }
  function isElementBefore(el, marker) {
    return !!(marker.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_PRECEDING);
  }
  function createPrintAnswerItem(labelText, bodyNode, options) {
    const item = document.createElement("div");
    item.className = "print-answer-item";
    if (options?.emptySection) item.classList.add("is-section-empty");
    if (labelText) {
      const label = document.createElement("div");
      label.className = "print-answer-label";
      label.textContent = labelText;
      item.appendChild(label);
    }
    let body;
    if (bodyNode instanceof HTMLElement) {
      body = bodyNode;
      body.className = "print-answer-body";
    } else {
      body = document.createElement("div");
      body.className = "print-answer-body";
      body.textContent = bodyNode;
    }
    item.appendChild(body);
    return item;
  }
  function buildAnswerBodyFromSource(source) {
    const body = document.createElement("div");
    if (source.classList.contains("exam-blank")) {
      const answer = source.querySelector(".exam-blank-answer");
      if (!(answer instanceof HTMLElement)) return null;
      if (!(answer.textContent || "").trim() && !answer.querySelector(".katex, img, svg, math")) {
        return null;
      }
      appendClonedChildren(body, answer);
      return body;
    }
    if (source.classList.contains("exam-choices")) {
      const letters = [];
      source.querySelectorAll(".exam-choice-option[data-answer='true']").forEach((opt) => {
        const letter = opt.getAttribute("data-choice");
        if (letter) letters.push(letter);
      });
      if (!letters.length) return null;
      body.textContent = letters.join("\u3001");
      return body;
    }
    if (source.classList.contains("exam-solution")) {
      const content = source.querySelector(".exam-solution-content");
      if (!(content instanceof HTMLElement)) return null;
      if (!(content.textContent || "").trim() && !content.querySelector(".katex, img, svg, math")) {
        return null;
      }
      appendClonedChildren(body, content);
      return body;
    }
    return null;
  }
  function collectQuestionNumbersInRange(root, startEl, endEl) {
    const nums = [];
    root.querySelectorAll("ol").forEach((ol) => {
      if (ol.closest(".related-exams")) return;
      if (!isElementAfter(ol, startEl)) return;
      if (endEl && !isElementBefore(ol, endEl)) return;
      let start = Number.parseInt(ol.getAttribute("start") || "1", 10);
      if (!Number.isFinite(start)) start = 1;
      const items = Array.from(ol.children).filter((child) => child.tagName === "LI");
      items.forEach((_item, index) => {
        nums.push(start + index);
      });
    });
    return Array.from(new Set(nums)).sort((a, b) => a - b);
  }
  function collectSubsectionHeadingsInRange(root, startEl, endEl) {
    return Array.from(root.querySelectorAll("h3")).filter((heading) => {
      if (heading.closest(".related-exams")) return false;
      if (!isElementAfter(heading, startEl)) return false;
      if (endEl && !isElementBefore(heading, endEl)) return false;
      return !!(heading.textContent || "").trim();
    });
  }
  function createAnswerSection(titleText) {
    const section = document.createElement("div");
    section.className = "print-answer-section";
    const title = document.createElement("h3");
    title.className = "print-answer-section-title";
    title.textContent = titleText;
    section.appendChild(title);
    return section;
  }
  function buildPrintAnswersAppendix() {
    const root = document.querySelector(".wiki-content .exam-page-main") || document.querySelector(".wiki-content");
    if (!root) return null;
    const allSources = Array.from(
      root.querySelectorAll(
        ".exam-blank[aria-pressed], .exam-choices[data-has-answer='true'], .exam-solution"
      )
    ).filter((el) => !el.closest(".related-exams") && !el.closest(".print-answers-appendix"));
    const sectionHeadings = Array.from(root.querySelectorAll("h2")).filter(
      (el) => !el.closest(".related-exams")
    );
    const appendix = document.createElement("section");
    appendix.className = "print-answers-appendix";
    appendix.setAttribute("aria-label", "\u7B54\u6848");
    const title = document.createElement("h2");
    title.className = "print-answers-appendix-title";
    title.textContent = "\u7B54\u6848";
    appendix.appendChild(title);
    let itemCount = 0;
    const appendSourceItem = (target, source, useLocalLabel) => {
      const body = buildAnswerBodyFromSource(source);
      if (!body) return false;
      itemCount += 1;
      const labelText = useLocalLabel ? buildLocalAnswerLabel(source, itemCount).label : buildPrintAnswerLabel(source, itemCount);
      target.appendChild(createPrintAnswerItem(labelText, body));
      return true;
    };
    if (!sectionHeadings.length) {
      allSources.forEach((source) => {
        appendSourceItem(appendix, source, false);
      });
      return itemCount > 0 ? appendix : null;
    }
    const prefaceSources = allSources.filter(
      (source) => isElementBefore(source, sectionHeadings[0])
    );
    prefaceSources.forEach((source) => {
      appendSourceItem(appendix, source, false);
    });
    sectionHeadings.forEach((heading, index) => {
      const nextHeading = sectionHeadings[index + 1] || null;
      const headingText = (heading.textContent || "").trim() || `\u7B2C ${index + 1} \u9898`;
      const section = createAnswerSection(headingText);
      const sectionSources = allSources.filter((source) => {
        if (!isElementAfter(source, heading)) return false;
        if (nextHeading && !isElementBefore(source, nextHeading)) return false;
        return true;
      });
      const numberedEntries = {};
      const otherEntries = [];
      sectionSources.forEach((source) => {
        const body = buildAnswerBodyFromSource(source);
        if (!body) return;
        const local = buildLocalAnswerLabel(
          source,
          Object.keys(numberedEntries).length + otherEntries.length + 1
        );
        if (local.sort != null && Number.isFinite(local.sort)) {
          if (!numberedEntries[local.sort]) {
            numberedEntries[local.sort] = [];
          }
          numberedEntries[local.sort].push({ label: local.label, body });
        } else {
          otherEntries.push({ label: local.label, body });
        }
      });
      let expectedNumbers = collectQuestionNumbersInRange(root, heading, nextHeading);
      const numberedKeys = Object.keys(numberedEntries).map(Number).sort((a, b) => a - b);
      if (!expectedNumbers.length && numberedKeys.length) {
        const maxNum = numberedKeys[numberedKeys.length - 1];
        const minNum = numberedKeys[0];
        for (let n = minNum; n <= maxNum; n += 1) expectedNumbers.push(n);
      }
      if (expectedNumbers.length) {
        expectedNumbers.forEach((num) => {
          const entries = numberedEntries[num];
          if (entries?.length) {
            entries.forEach((entry) => {
              itemCount += 1;
              section.appendChild(createPrintAnswerItem(entry.label, entry.body));
            });
            delete numberedEntries[num];
          } else {
            itemCount += 1;
            section.appendChild(createPrintAnswerItem(`${num}.`, "\u6682\u65E0\u7B54\u6848"));
          }
        });
        Object.keys(numberedEntries).map(Number).sort((a, b) => a - b).forEach((num) => {
          numberedEntries[num].forEach((entry) => {
            itemCount += 1;
            section.appendChild(createPrintAnswerItem(entry.label, entry.body));
          });
        });
      } else {
        numberedKeys.forEach((num) => {
          numberedEntries[num].forEach((entry) => {
            itemCount += 1;
            section.appendChild(createPrintAnswerItem(entry.label, entry.body));
          });
        });
      }
      otherEntries.forEach((entry) => {
        itemCount += 1;
        section.appendChild(createPrintAnswerItem(entry.label, entry.body));
      });
      if (!section.querySelector(".print-answer-item")) {
        const subsections = collectSubsectionHeadingsInRange(root, heading, nextHeading);
        if (subsections.length) {
          subsections.forEach((subheading) => {
            itemCount += 1;
            section.appendChild(
              createPrintAnswerItem((subheading.textContent || "").trim(), "\u6682\u65E0\u7B54\u6848")
            );
          });
        } else {
          itemCount += 1;
          section.appendChild(createPrintAnswerItem("", "\u6682\u65E0\u7B54\u6848", { emptySection: true }));
        }
      }
      appendix.appendChild(section);
    });
    return itemCount > 0 ? appendix : null;
  }

  // src/print-takeover.ts
  var takeoverBound = false;
  var openDialogHandler = null;
  function onPrintShortcut(event) {
    if (!(event.ctrlKey || event.metaKey)) return;
    if (event.key !== "p" && event.key !== "P") return;
    event.preventDefault();
    event.stopImmediatePropagation();
    openDialogHandler?.();
  }
  function onNativePrintClick(event) {
    const target = event.target;
    if (!(target instanceof Element)) return;
    if (!target.closest("#examPrint")) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    openDialogHandler?.();
  }
  function bindTakeover() {
    if (takeoverBound) return;
    window.addEventListener("keydown", onPrintShortcut, true);
    document.addEventListener("click", onNativePrintClick, true);
    takeoverBound = true;
  }
  function unbindTakeover() {
    if (!takeoverBound) return;
    window.removeEventListener("keydown", onPrintShortcut, true);
    document.removeEventListener("click", onNativePrintClick, true);
    takeoverBound = false;
  }
  function applyPrintTakeover(enabled, openDialog) {
    openDialogHandler = openDialog;
    if (enabled) {
      bindTakeover();
    } else {
      unbindTakeover();
    }
  }

  // src/settings.ts
  var TAKEOVER_PRINT_KEY = "takeoverPrint";
  var DEFAULT_TAKEOVER_PRINT = true;
  async function getTakeoverPrint() {
    try {
      if (typeof chrome?.storage?.local?.get === "function") {
        const result = await chrome.storage.local.get(TAKEOVER_PRINT_KEY);
        const value = result[TAKEOVER_PRINT_KEY];
        return typeof value === "boolean" ? value : DEFAULT_TAKEOVER_PRINT;
      }
    } catch {
    }
    try {
      const raw = localStorage.getItem(TAKEOVER_PRINT_KEY);
      if (raw === null) return DEFAULT_TAKEOVER_PRINT;
      return raw === "true";
    } catch {
      return DEFAULT_TAKEOVER_PRINT;
    }
  }
  async function setTakeoverPrint(enabled) {
    try {
      if (typeof chrome?.storage?.local?.set === "function") {
        await chrome.storage.local.set({ [TAKEOVER_PRINT_KEY]: enabled });
        return;
      }
    } catch {
    }
    try {
      localStorage.setItem(TAKEOVER_PRINT_KEY, String(enabled));
    } catch {
    }
  }
  function onTakeoverPrintChanged(callback) {
    if (typeof chrome?.storage?.onChanged?.addListener !== "function") return;
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local") return;
      const change = changes[TAKEOVER_PRINT_KEY];
      if (!change) return;
      callback(
        typeof change.newValue === "boolean" ? change.newValue : DEFAULT_TAKEOVER_PRINT
      );
    });
  }

  // src/print.ts
  var removedPrintInfoNodes = [];
  function shouldPrintExamInfo() {
    return document.documentElement.dataset.bdwpPrintInfo === "true";
  }
  function isExamInfoAside(el) {
    if (!(el instanceof HTMLElement) || el.tagName !== "ASIDE") return false;
    const heading = el.querySelector(".border-b p, .border-b h2, .border-b h3");
    return (heading?.textContent || "").trim() === "\u8BD5\u9898\u4FE1\u606F";
  }
  function getExamInfoElements() {
    const elements = [];
    const seen = /* @__PURE__ */ new Set();
    const add = (el) => {
      if (!(el instanceof HTMLElement) || seen.has(el)) return;
      seen.add(el);
      elements.push(el);
    };
    add(document.getElementById("examInfoBox"));
    document.querySelectorAll(".exam-info-box").forEach(add);
    document.querySelectorAll(".exam-page-main > aside").forEach((el) => {
      if (isExamInfoAside(el)) add(el);
    });
    return elements;
  }
  function hideExamInfoForPrint() {
    removedPrintInfoNodes = [];
    getExamInfoElements().forEach((el) => {
      const parent = el.parentNode;
      if (!parent) return;
      removedPrintInfoNodes.push({
        el,
        parent,
        nextSibling: el.nextSibling
      });
      el.remove();
    });
  }
  function restoreExamInfoAfterPrint() {
    removedPrintInfoNodes.forEach(({ el, parent, nextSibling }) => {
      if (el.isConnected) return;
      if (nextSibling && nextSibling.parentNode === parent) {
        parent.insertBefore(el, nextSibling);
      } else {
        parent.appendChild(el);
      }
    });
    removedPrintInfoNodes = [];
  }
  function getExamState() {
    return window.__examState;
  }
  function createDialog() {
    const dialog = document.createElement("dialog");
    dialog.id = "bdwpPrintDialog";
    dialog.className = "bdwp-print-dialog";
    dialog.setAttribute("aria-labelledby", "bdwpPrintDialogTitle");
    dialog.innerHTML = `
    <div class="bdwp-print-dialog-panel">
      <h2 id="bdwpPrintDialogTitle" class="bdwp-print-dialog-title">\u6253\u5370\u9009\u9879</h2>
      <p class="bdwp-print-dialog-desc">\u9009\u62E9\u8981\u5305\u542B\u5728\u6253\u5370\u7A3F\u4E2D\u7684\u5185\u5BB9\u3002</p>
      <label class="bdwp-print-dialog-option">
        <input id="bdwpPrintInfo" type="checkbox" />
        <span>\u6253\u5370\u8BD5\u9898\u6982\u8981\u4FE1\u606F</span>
      </label>
      <label class="bdwp-print-dialog-option bdwp-print-dialog-option-spaced">
        <input id="bdwpPrintAnswers" type="checkbox" checked />
        <span>\u6253\u5370\u7B54\u6848</span>
      </label>
      <fieldset id="bdwpPrintAnswerPlacement" class="bdwp-print-dialog-fieldset">
        <legend class="bdwp-print-dialog-legend">\u7B54\u6848\u4F4D\u7F6E</legend>
        <label class="bdwp-print-dialog-radio">
          <input type="radio" name="bdwpPrintAnswerPlacement" value="inline" />
          <span>\u653E\u5728\u539F\u9898\u4F4D\u7F6E</span>
        </label>
        <label class="bdwp-print-dialog-radio">
          <input type="radio" name="bdwpPrintAnswerPlacement" value="end" checked />
          <span>\u7EDF\u4E00\u653E\u5728\u6700\u540E</span>
        </label>
      </fieldset>
      <label class="bdwp-print-dialog-option bdwp-print-dialog-option-spaced bdwp-print-dialog-takeover">
        <input id="bdwpTakeoverPrint" type="checkbox" checked />
        <span>\u4EC5\u6269\u5C55\u63A5\u7BA1\u6253\u5370\uFF08\u62E6\u622A Ctrl/Cmd+P \u4E0E\u4E3B\u7AD9\u6253\u5370\u6309\u94AE\uFF09</span>
      </label>
      <div class="bdwp-print-dialog-actions">
        <button id="bdwpPrintDialogCancel" class="bdwp-print-dialog-btn bdwp-print-dialog-btn-secondary" type="button">\u53D6\u6D88</button>
        <button id="bdwpPrintDialogConfirm" class="bdwp-print-dialog-btn bdwp-print-dialog-btn-primary" type="button">\u6253\u5370</button>
      </div>
    </div>
  `;
    return dialog;
  }
  function revealAllAnswers(prePrintState) {
    const examState = getExamState();
    if (!examState?.getAllShown?.()) {
      examState?.toggleAll?.();
      prePrintState.wasHidden = true;
    }
    document.querySelectorAll(".exam-solution:not([open])").forEach((el) => {
      el.setAttribute("open", "");
      prePrintState.solutions.push(el);
    });
    document.querySelectorAll(".exam-blank[aria-pressed='false']").forEach((el) => {
      el.setAttribute("aria-pressed", "true");
      prePrintState.blanks.push(el);
    });
    document.querySelectorAll(
      ".exam-choices[data-has-answer='true'][data-revealed='false']"
    ).forEach((group) => {
      group.querySelectorAll(".exam-choice-option").forEach((opt) => {
        if (opt.getAttribute("data-answer") === "true") {
          opt.classList.add("is-correct");
          const input = opt.querySelector(
            ".exam-choice-input"
          );
          if (input) input.checked = true;
        }
      });
      group.setAttribute("data-revealed", "true");
      prePrintState.choices.push(group);
    });
  }
  function collapseInlineAnswersForEndPrint() {
    document.querySelectorAll(".exam-solution[open]").forEach((el) => {
      el.removeAttribute("open");
    });
    document.querySelectorAll(".exam-blank[aria-pressed='true']").forEach((el) => {
      el.setAttribute("aria-pressed", "false");
    });
    document.querySelectorAll(".exam-choices[data-revealed='true']").forEach((group) => {
      group.setAttribute("data-revealed", "false");
      group.querySelectorAll(".exam-choice-option").forEach((opt) => {
        opt.classList.remove("is-correct", "is-wrong", "is-missed");
        const input = opt.querySelector(".exam-choice-input");
        if (input) input.checked = false;
      });
    });
  }
  function restoreAnswers(prePrintState) {
    if (prePrintState.wasHidden) {
      getExamState()?.toggleAll?.();
    }
    prePrintState.solutions.forEach((el) => el.removeAttribute("open"));
    prePrintState.blanks.forEach(
      (el) => el.setAttribute("aria-pressed", "false")
    );
    prePrintState.choices.forEach((group) => {
      group.querySelectorAll(".exam-choice-option").forEach((opt) => {
        opt.classList.remove("is-correct");
        const input = opt.querySelector(".exam-choice-input");
        if (input) input.checked = false;
      });
      group.setAttribute("data-revealed", "false");
    });
  }
  function mountPrintFeature() {
    if (document.getElementById("bdwpPrintDialog")) return;
    if (!document.querySelector(".exam-page-main")) return;
    const dialog = createDialog();
    document.body.append(dialog);
    const printAnswersInput = document.getElementById(
      "bdwpPrintAnswers"
    );
    const printInfoInput = document.getElementById(
      "bdwpPrintInfo"
    );
    const printAnswerPlacementFieldset = document.getElementById(
      "bdwpPrintAnswerPlacement"
    );
    const takeoverPrintInput = document.getElementById(
      "bdwpTakeoverPrint"
    );
    const cancelButton = document.getElementById("bdwpPrintDialogCancel");
    const confirmButton = document.getElementById("bdwpPrintDialogConfirm");
    let printAnswersAppendix = null;
    let prePrintState = null;
    let printWithAnswers = true;
    let printWithInfo = false;
    let printAnswerPlacement = "end";
    const getSelectedAnswerPlacement = () => {
      const selected = printAnswerPlacementFieldset?.querySelector(
        'input[name="bdwpPrintAnswerPlacement"]:checked'
      );
      return selected instanceof HTMLInputElement && selected.value === "inline" ? "inline" : "end";
    };
    const setAnswerPlacementInputs = (placement) => {
      printAnswerPlacementFieldset?.querySelectorAll('input[name="bdwpPrintAnswerPlacement"]').forEach((input) => {
        if (input instanceof HTMLInputElement) {
          input.checked = input.value === placement;
        }
      });
    };
    const syncPrintAnswerPlacementEnabled = () => {
      if (!(printAnswerPlacementFieldset instanceof HTMLFieldSetElement)) return;
      const enabled = printAnswersInput instanceof HTMLInputElement ? printAnswersInput.checked : true;
      printAnswerPlacementFieldset.disabled = !enabled;
    };
    const openDialog = () => {
      if (printAnswersInput) printAnswersInput.checked = printWithAnswers;
      if (printInfoInput) printInfoInput.checked = printWithInfo;
      setAnswerPlacementInputs(printAnswerPlacement);
      syncPrintAnswerPlacementEnabled();
      void syncTakeoverCheckbox();
      if (!dialog.open) dialog.showModal();
    };
    const syncTakeoverCheckbox = async () => {
      if (!(takeoverPrintInput instanceof HTMLInputElement)) return;
      takeoverPrintInput.checked = await getTakeoverPrint();
    };
    const syncPrintTakeover = async () => {
      applyPrintTakeover(await getTakeoverPrint(), openDialog);
    };
    const closeDialog = () => {
      if (dialog.open) dialog.close();
    };
    const startPrint = (withAnswers, placement, withInfo) => {
      printWithAnswers = withAnswers;
      printWithInfo = withInfo;
      printAnswerPlacement = withAnswers ? placement : "inline";
      document.documentElement.dataset.printAnswers = withAnswers ? "true" : "false";
      document.documentElement.dataset.printInfo = withInfo ? "true" : "false";
      document.documentElement.dataset.bdwpPrintInfo = withInfo ? "true" : "false";
      if (withAnswers) {
        document.documentElement.dataset.printAnswerPlacement = placement;
      } else {
        delete document.documentElement.dataset.printAnswerPlacement;
      }
      closeDialog();
      window.print();
    };
    mountPrintButton(openDialog);
    void syncPrintTakeover();
    onTakeoverPrintChanged(() => {
      void syncPrintTakeover();
      void syncTakeoverCheckbox();
    });
    takeoverPrintInput?.addEventListener("change", () => {
      if (!(takeoverPrintInput instanceof HTMLInputElement)) return;
      void setTakeoverPrint(takeoverPrintInput.checked).then(() => {
        void syncPrintTakeover();
      });
    });
    window.addEventListener("beforeprint", () => {
      const withAnswers = document.documentElement.dataset.printAnswers !== "false";
      const placement = document.documentElement.dataset.printAnswerPlacement === "end" ? "end" : "inline";
      printWithAnswers = withAnswers;
      printAnswerPlacement = withAnswers ? placement : "inline";
      prePrintState = {
        blanks: [],
        solutions: [],
        choices: [],
        withAnswers,
        placement
      };
      if (withAnswers && placement === "end") {
        printAnswersAppendix = buildPrintAnswersAppendix();
        if (printAnswersAppendix) {
          document.querySelector(".wiki-content")?.appendChild(printAnswersAppendix);
        }
        collapseInlineAnswersForEndPrint();
      } else if (withAnswers) {
        revealAllAnswers(prePrintState);
      }
      document.querySelectorAll(".print-footer").forEach((el) => {
        el.remove();
      });
      if (!shouldPrintExamInfo()) {
        hideExamInfoForPrint();
      }
    });
    window.addEventListener("afterprint", () => {
      restoreExamInfoAfterPrint();
      printAnswersAppendix?.remove();
      printAnswersAppendix = null;
      delete document.documentElement.dataset.printAnswers;
      delete document.documentElement.dataset.printAnswerPlacement;
      delete document.documentElement.dataset.printInfo;
      delete document.documentElement.dataset.bdwpPrintInfo;
      if (!prePrintState) return;
      if (prePrintState.withAnswers && prePrintState.placement !== "end") {
        restoreAnswers(prePrintState);
      }
      prePrintState = null;
    });
    printAnswersInput?.addEventListener("change", syncPrintAnswerPlacementEnabled);
    cancelButton?.addEventListener("click", closeDialog);
    confirmButton?.addEventListener("click", () => {
      startPrint(
        printAnswersInput?.checked ?? true,
        getSelectedAnswerPlacement(),
        printInfoInput?.checked ?? false
      );
    });
    dialog.addEventListener("click", (event) => {
      if (event.target === dialog) closeDialog();
    });
  }

  // src/content.ts
  function isExamPage() {
    return document.querySelector(".exam-page-main") !== null;
  }
  function syncPrintFeature() {
    try {
      if (!isExamPage()) return;
      if (!document.getElementById("bdwpPrintDialog")) {
        mountPrintFeature();
        return;
      }
      if (needsPlacementSync()) {
        ensurePrintButtonPlacement();
      }
    } catch (error) {
      console.error("[BYR Docs Wiki Print] init failed:", error);
    }
  }
  function maybeStopObserver(observer2) {
    if (isPrintUiReady()) {
      observer2.disconnect();
    }
  }
  var syncScheduled = false;
  var observer = new MutationObserver(() => {
    if (!isExamPage()) return;
    if (syncScheduled) return;
    syncScheduled = true;
    requestAnimationFrame(() => {
      syncScheduled = false;
      if (!isExamPage()) return;
      syncPrintFeature();
      maybeStopObserver(observer);
    });
  });
  function init() {
    syncPrintFeature();
    maybeStopObserver(observer);
  }
  observer.observe(document.documentElement, { childList: true, subtree: true });
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init, { once: true });
  } else {
    init();
  }
})();
