"use strict";
(() => {
  // src/print.ts
  var WIKI_SOURCE_URL = "https://wiki.byrdocs.org";
  var LICENSE_URL = "https://creativecommons.org/licenses/by-nc-sa/4.0/";
  function getExamState() {
    return window.__examState;
  }
  function createDialog() {
    const dialog = document.createElement("dialog");
    dialog.id = "bdwpPrintDialog";
    dialog.className = "bdwp-print-dialog";
    dialog.setAttribute("aria-labelledby", "bdwpPrintDialogTitle");
    dialog.innerHTML = `
    <div class="bdwp-print-dialog-panel">
      <h2 id="bdwpPrintDialogTitle" class="bdwp-print-dialog-title">\u6253\u5370\u9009\u9879</h2>
      <p class="bdwp-print-dialog-desc">\u9009\u62E9\u8981\u5305\u542B\u5728\u6253\u5370\u7A3F\u4E2D\u7684\u5185\u5BB9\u3002</p>
      <label class="bdwp-print-dialog-option">
        <input id="bdwpPrintInfo" type="checkbox" checked />
        <span>\u6253\u5370\u8BD5\u9898\u6982\u8981\u4FE1\u606F</span>
      </label>
      <label class="bdwp-print-dialog-option bdwp-print-dialog-option-spaced">
        <input id="bdwpPrintAnswers" type="checkbox" checked />
        <span>\u6253\u5370\u7B54\u6848</span>
      </label>
      <div class="bdwp-print-dialog-actions">
        <button id="bdwpPrintDialogCancel" class="bdwp-print-dialog-btn bdwp-print-dialog-btn-secondary" type="button">\u53D6\u6D88</button>
        <button id="bdwpPrintDialogConfirm" class="bdwp-print-dialog-btn bdwp-print-dialog-btn-primary" type="button">\u6253\u5370</button>
      </div>
    </div>
  `;
    return dialog;
  }
  function createFab() {
    const button = document.createElement("button");
    button.id = "bdwpPrintFab";
    button.type = "button";
    button.className = "bdwp-print-fab";
    button.setAttribute("aria-label", "\u6253\u5370\u8BD5\u5377");
    button.title = "\u6253\u5370\u8BD5\u5377";
    button.innerHTML = `
    <svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8">
      <polyline points="6 9 6 2 18 2 18 9"></polyline>
      <path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path>
      <rect x="6" y="14" width="12" height="8"></rect>
    </svg>
  `;
    return button;
  }
  function revealAllAnswers(prePrintState) {
    const examState = getExamState();
    if (!examState?.getAllShown?.()) {
      examState?.toggleAll?.();
      prePrintState.wasHidden = true;
    }
    document.querySelectorAll(".exam-solution:not([open])").forEach((el) => {
      el.setAttribute("open", "");
      prePrintState.solutions.push(el);
    });
    document.querySelectorAll(".exam-blank[aria-pressed='false']").forEach((el) => {
      el.setAttribute("aria-pressed", "true");
      prePrintState.blanks.push(el);
    });
    document.querySelectorAll(
      ".exam-choices[data-has-answer='true'][data-revealed='false']"
    ).forEach((group) => {
      group.querySelectorAll(".exam-choice-option").forEach((opt) => {
        if (opt.getAttribute("data-answer") === "true") {
          opt.classList.add("is-correct");
          const input = opt.querySelector(
            ".exam-choice-input"
          );
          if (input) input.checked = true;
        }
      });
      group.setAttribute("data-revealed", "true");
      prePrintState.choices.push(group);
    });
  }
  function restoreAnswers(prePrintState) {
    if (prePrintState.wasHidden) {
      getExamState()?.toggleAll?.();
    }
    prePrintState.solutions.forEach((el) => el.removeAttribute("open"));
    prePrintState.blanks.forEach(
      (el) => el.setAttribute("aria-pressed", "false")
    );
    prePrintState.choices.forEach((group) => {
      group.querySelectorAll(".exam-choice-option").forEach((opt) => {
        opt.classList.remove("is-correct");
        const input = opt.querySelector(".exam-choice-input");
        if (input) input.checked = false;
      });
      group.setAttribute("data-revealed", "false");
    });
  }
  function mountPrintFeature() {
    if (document.getElementById("bdwpPrintFab")) return;
    if (!document.querySelector(".exam-page-main")) return;
    const dialog = createDialog();
    const fab = createFab();
    document.body.append(dialog, fab);
    const printAnswersInput = document.getElementById(
      "bdwpPrintAnswers"
    );
    const printInfoInput = document.getElementById(
      "bdwpPrintInfo"
    );
    const cancelButton = document.getElementById("bdwpPrintDialogCancel");
    const confirmButton = document.getElementById("bdwpPrintDialogConfirm");
    let printUrlFooter = null;
    let prePrintState = null;
    let printWithAnswers = true;
    let printWithInfo = true;
    const openDialog = () => {
      if (printAnswersInput) printAnswersInput.checked = printWithAnswers;
      if (printInfoInput) printInfoInput.checked = printWithInfo;
      if (!dialog.open) dialog.showModal();
    };
    const closeDialog = () => {
      if (dialog.open) dialog.close();
    };
    const startPrint = (withAnswers, withInfo) => {
      printWithAnswers = withAnswers;
      printWithInfo = withInfo;
      document.documentElement.dataset.printAnswers = withAnswers ? "true" : "false";
      document.documentElement.dataset.printInfo = withInfo ? "true" : "false";
      closeDialog();
      window.print();
    };
    window.addEventListener("beforeprint", () => {
      const withAnswers = document.documentElement.dataset.printAnswers !== "false";
      printWithAnswers = withAnswers;
      prePrintState = {
        blanks: [],
        solutions: [],
        choices: [],
        withAnswers
      };
      if (withAnswers && prePrintState) {
        revealAllAnswers(prePrintState);
      }
      printUrlFooter = document.createElement("div");
      printUrlFooter.className = "print-footer";
      printUrlFooter.style.display = "none";
      printUrlFooter.innerHTML = `\u672C\u9875\u9762\u6253\u5370\u81EA <a href="${window.location.href}">${window.location.href}</a><br>\u6765\u6E90\uFF1A<a href="${WIKI_SOURCE_URL}">BYR Docs \u7EF4\u57FA\u771F\u9898</a><br>\u9664\u975E\u53E6\u6709\u58F0\u660E\uFF0C\u672C\u6587\u4EF6\u5185\u5BB9\u91C7\u7528 <a href="${LICENSE_URL}">CC BY-NC-SA 4.0</a> \u6388\u6743\u3002`;
      document.querySelector(".wiki-content")?.appendChild(printUrlFooter);
    });
    window.addEventListener("afterprint", () => {
      printUrlFooter?.remove();
      printUrlFooter = null;
      if (!prePrintState) return;
      if (prePrintState.withAnswers) {
        restoreAnswers(prePrintState);
      }
      prePrintState = null;
    });
    fab.addEventListener("click", openDialog);
    cancelButton?.addEventListener("click", closeDialog);
    confirmButton?.addEventListener("click", () => {
      startPrint(
        printAnswersInput?.checked ?? true,
        printInfoInput?.checked ?? true
      );
    });
    dialog.addEventListener("click", (event) => {
      if (event.target === dialog) closeDialog();
    });
    window.addEventListener(
      "keydown",
      (event) => {
        if (!(event.ctrlKey || event.metaKey)) return;
        if (event.key !== "p" && event.key !== "P") return;
        event.preventDefault();
        event.stopImmediatePropagation();
        openDialog();
      },
      true
    );
  }

  // src/content.ts
  function isExamPage() {
    return document.querySelector(".exam-page-main") !== null;
  }
  function init() {
    if (!isExamPage()) return;
    mountPrintFeature();
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init, { once: true });
  } else {
    init();
  }
  var observer = new MutationObserver(() => {
    if (isExamPage() && !document.getElementById("bdwpPrintFab")) {
      mountPrintFeature();
    }
  });
  observer.observe(document.documentElement, { childList: true, subtree: true });
})();
